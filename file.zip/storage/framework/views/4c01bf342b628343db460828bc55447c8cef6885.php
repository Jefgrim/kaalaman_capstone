

<?php $__env->startSection('title'); ?>
    <?php echo e($thread->title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('UserIcon'); ?>
    <?php if(auth()->guard()->guest()): ?>
        <div class="user">
            <div class="userDropDown headerIcons">
                <i class="fa-regular fa-user guestIcon"></i>
                <div class="guestUser-Section" id="userSection" style="display: none">
                    <span>Guest Mode</span>
                </div>
             </div>
            <div class="headerIcon">
                 <i class="fa-regular fa-lightbulb headerIcons" id="darkmodeBtn"></i>
            </div>
        </div>
     <?php else: ?>
        <div class="user">
            <div class="userDropDown headerIcons">
                <img src=<?php echo e(asset("images/AvatarUsers2_20.png")); ?> />
                <div class="user-Section" id="userSection" style="display: none">
                    <span><?php echo e(Auth::user()->name); ?></span>
                    <button>Account Profile</button>
                    <button> 
                        <a class="lagout" href="<?php echo e(route('logout')); ?>"
                            onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();">
                            <?php echo e(__('Logout')); ?>

                        </a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                        </form>
                    </button>
                </div>
            </div>

            <div class="headerIcon">
                <i class="fa-regular fa-bell headerIcons" id="notification"></i>
                <i class="fa-regular fa-lightbulb headerIcons" id="darkmodeBtn"></i>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('commentContent'); ?>
<div class="threadNavContainer">
    <div class="backButtonContainer">
        <a href="/thread"><i class="fa-solid fa-circle-left"></i></a>
    </div>
</div>
<div class="threadContent <?php echo e($thread->category); ?>">
    <div class="avatarTextsContainer">
        <div class="threadUserAvatar">
            <img src=".//images/Avatar Users2_1.png">
            <span><?php echo e($thread->users->name); ?></span>
        </div>
        <div class="threadTextsContainer">
            <div class="threadTexts">
                <span><?php echo e($thread->category); ?></span>
                <span style="font-size: larger;"><?php echo e($thread->title); ?></span>
                <span><?php echo e($thread->threadpost); ?></span>
            </div>
        </div>
    </div>
    <div class="threadReaction">
        <div class="thumbsUpDownContainer">
            <div class="threadThumbsUp">
                <i class="fa-regular fa-thumbs-up" id="likepost5"></i>
            </div>
            <div class="threadThumbsDown">
                <i class="fa-regular fa-thumbs-down" id="dislikepost5"></i>
            </div>
        </div>
        <div class="replyBtnContainer">
            <i class="fa-solid fa-reply" type="button" data-bs-toggle="modal" data-bs-target="#replyModal" id="user1" onClick="reply_click()"></i>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('replyModal'); ?>
    <div class="modal fade" id="replyModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                <script type="text/javascript">
                    function reply_click(){
                        console.log(event.srcElement.id);
                    }
                </script>
            </div>
        </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kodego\kaalaman_capstone\resources\views/comments/index.blade.php ENDPATH**/ ?>