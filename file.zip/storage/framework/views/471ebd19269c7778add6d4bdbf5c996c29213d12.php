

<?php $__env->startSection('title'); ?>
    Mission
<?php $__env->stopSection(); ?>

<?php $__env->startSection('mission'); ?>
  <div class="centerContainer">
    <div class="centerContent">
      <a class="footerLinks" href="/"><i class="fa-solid fa-house"></i></a>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kodego\kaalaman_capstone\resources\views/mission/index.blade.php ENDPATH**/ ?>