

<?php $__env->startSection('threadContent'); ?>
    <?php $__currentLoopData = $threads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="threadContent <?php echo e($item->category); ?>">
            <div class="avatarTextsContainer">
                <div class="threadUserAvatar">
                    <img src=".//images/Avatar Users2_1.png">
                    <span><?php echo e($item->users->name); ?></span>
                </div>
                <div class="threadTextsContainer">
                    <div class="threadTexts">
                        <span><?php echo e($item->category); ?></span>
                        <span style="font-size: larger;"><?php echo e($item->title); ?></span>
                        <span><?php echo e($item->threadpost); ?></span>
                    </div>
                </div>
            </div>
            <div class="threadReaction">
                <div class="thumbsUpDownContainer">
                    <div class="threadThumbsUp">
                        <i class="fa-regular fa-thumbs-up" id="likepost5"></i>
                    </div>
                    <div class="threadThumbsDown">
                        <i class="fa-regular fa-thumbs-down" id="dislikepost5"></i>
                    </div>
                </div>
                <div class="replyBtnContainer">
                    <a href='<?php echo e(url('/thread/' . $item->id)); ?>'><i class="fa-solid fa-comment-dots"></i></a>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('postThreadContent'); ?>
    <?php if(auth()->guard()->guest()): ?>
        <form class="guestPostThreadContent">
            <div class="h2Container">
            <h2 class="guestthread-post">Log-in  or Register Below</h2>
           
        </div>
        <div class="guestSidebar">
                 
            <a class="Log-in" href="<?php echo e(route('login')); ?>">Log-in</a> 
               
            <a class="Register" href="<?php echo e(route('register')); ?>">Register</a>
               
            </div>
        </form>
    <?php else: ?>
        <form class="postThreadContent" action="/thread" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="h2Container">
            <h2 class="thread-post">CREATE A THREAD</h2>
            
            </div>

            <div class="category-title">
            <input
                type="text"
                placeholder="Title"
                id="titleInp"
                class="titleInp"
                name="title"
                required
            />

            <select id="selectCategory" class="selectCategory" name="category" required>
                <option value="" selected disabled>Select Category</option>
                <option value="Technology">Technology</option>
                <option value="E-commerce">E-Commerce</option>
                <option value="Health-Lifestyle">Health & Lifestyle</option>
                <option value="Games">Games</option>
                <option value="Food-Beverages">Food & Beverages</option>
            </select>
            </div>
            <div class="threadInpContainer">
            <textarea id="threadInp" class="threadInp" name="threadpost" required></textarea>
            </div>
            <div class="threadBtnContainer">
            
            <i id="expandBtn" class="fa-solid fa-maximize enlargebtn expandBtn"></i>
            <button type="submit" id="postBtn" class="postBtn">Post</button>
            </div>
      </form>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('latestContent'); ?>
    <div class="content-box">
        <img src=".//images/Avatar Users2_1.png" class="avatar">
        <div class="text-container">
            <?php if($latestPost == NULL): ?>
            <?php else: ?>
            <h3 class="latestTitle"><?php echo e($latestPost->title); ?></h3>
            <?php endif; ?>
            <?php if($latestPost == NULL): ?>
            <?php else: ?>
            <p class="p-1">By: <?php echo e($latestPost->users->name); ?></p>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('threads.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kodego\kaalaman_capstone\resources\views/threads/index.blade.php ENDPATH**/ ?>