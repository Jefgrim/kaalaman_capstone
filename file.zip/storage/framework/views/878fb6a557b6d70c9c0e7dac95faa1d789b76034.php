

<?php $__env->startSection('title'); ?>
    404 Not Found
<?php $__env->stopSection(); ?>

<?php $__env->startSection('404'); ?>
<div class="centerContainer"> 
    <div class="centerContent">
        <div class="content-404">
            <h2>404!</h2>
            <h3>We can't find what you are looking for, sorry.</h3>
            <a href="/" class="home_404">Home</a>
        </div> 
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kodego\kaalaman_capstone\resources\views/404/index.blade.php ENDPATH**/ ?>