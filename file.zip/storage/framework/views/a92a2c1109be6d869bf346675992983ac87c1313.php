

<?php $__env->startSection('title'); ?>
    <?php echo e($userProfile->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('userProfile'); ?>
    <h2>Profile of <?php echo e($userProfile->name); ?></h2>

    <div class="profileContiner">
        <div class="profilePicture">

        </div>
        <div class="profileInformation">
            <span>Name</span>

        </div>

    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kodego\kaalaman_capstone\resources\views/profile/index.blade.php ENDPATH**/ ?>