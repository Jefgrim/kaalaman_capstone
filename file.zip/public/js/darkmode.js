
const  Darkmode =() =>{
    document.body.classList.toggle("LigthMode")
}


export default Darkmode