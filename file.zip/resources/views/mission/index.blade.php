@extends('layouts.design')

@section('title')
    Mission
@endsection

@section('mission')
  <div class="centerContainer">
    <div class="centerContent">
      <a class="footerLinks" href="/"><i class="fa-solid fa-house"></i></a>
    </div>
  </div>
@endsection